# ecs171
Weiran Guo(912916431)
There are total 4 parts.
3a uses gradient descent which the batch size is N.
3c uses stochastical gradient descent with a fixed step size and batch size 1.
3d uses stochastical gradient descent with decaying step sizes and batch size 1.
4b uses linear support vector machine with stochastical gradient descent of decaying step sizes and batch size 1.

all usage:
python *.py

included package:
numpy
